"""PubMed Paper Fetcher - Fetch research papers with pharmaceutical company authors."""

__version__ = "0.1.0"
